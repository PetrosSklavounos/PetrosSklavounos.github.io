# Question 2 (Extra Credit)

Extend question 1 with the following bonus parts. The bonus will be graded manually.

Bonus (+10 for each): 
* Extend the game so that the user can specify the size of board that they want to play on (nxm).
* Have a computer so that can play relatively smart. (i.e. if there is a chance to get an SOS, it will go for it!).

Compilation Steps:  
After completing the makefile:
```
make
```
Followed by:
```
./q1.exe
```

Output (sample run):
```
>> Choose your player mode by typing A or B:
A)Player vs Player
B)Player vs Computer
B
>> You chose Player vs Computer
>> Now choose the board size by typing A, B:
A)3x3
B)5x5
B
>> Board is 5X5
- - - - -
- - - - -
- - - - -
- - - - -
- - - - -
>> You are Player 1
>> Player 1 Score: 0
>> Computer Score: 0
...and so on
OR: 
>> Choose your player mode by typing A or B:
A)Player vs Player
B)Player vs Computer
A
>> You chose Player vs Player
>> Now choose the board size by typing A, B:
A)3x3
B)5x5
A
>> Board is 3X3
- - -
- - -
- - -
>> Player 1 Score: 0
i>> Player 2 Score: 0

>> Player 1's Turn
>> Choose a valid spot by typing a number between 1 and 9:
...and so on
```  
