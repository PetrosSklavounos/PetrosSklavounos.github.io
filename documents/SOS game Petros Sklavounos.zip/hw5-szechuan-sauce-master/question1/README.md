## Question 1

Write the SOS game that is playable by 2 players. More information can be found on: <a href="https://en.wikipedia.org/wiki/SOS_(game)">https://en.wikipedia.org/wiki/SOS_(game)</a>

Include the following requirements:
* The game should be split up into multiple files.
* The game should be compiled using a makefile. The game will be compiled with make.
* The game should have a game board of 5x5.
* The number of SOS points should be counted per player.
* The game ends when the entire board is filled and the winner is declared.
* One should be able to do a rematch.
* Give the option for a player to play against the computer. 
* Print the current state of the game after each turn.

This question is 100 points (50 points for quality & 50 points for output).

Please answer the bonus parts of this question in the question2 folder.

Compile Steps:
After creating the makefile:
```
make
```
Followed by:
```
./q1.exe
```
in order to run.

Output:
```
>> Choose your player mode by typing A or B:
A)Player vs Player
B)Player vs Computer
B
>> You chose Player vs Computer
>> Now choose the board size by typing A, B:
A)3x3
B)5x5
B
>> Board is 5X5
- - - - -
- - - - -
- - - - -
- - - - -
- - - - -
>> You are Player 1
>> Player 1 Score: 0
>> Computer Score: 0

>> Player 1's Turn
>> Choose a valid spot by typing a number between 1 and 25:
4
>> Capital S or O?
>> Capital S or O?
S
- - - S -
- - - - -
- - - - -
- - - - -
- - - - -
>> Player one Score: 0
>> Player two Score: 0
>> Computer moves:
O O O S O
O O - O -
- - S S -
- - - O -
- - - S -
>> Player one Score: 2
>> Player two Score: 0

>> Player 1's Turn
>> Choose a valid spot by typing a number between 1 and 25:
1
>> Choose a valid spot by typing a number between 1 and 25:
8
>> Capital S or O?
>> Capital S or O?
S
O O O S O
O O S O -
- - S S -
- - - O -
- - - S -
>> Player one Score: 2
>> Player two Score: 0

O
O S S O O
S O O S S
O O S O O
O S O S O
O O S S O
>> Player one Score: 2
>> Player two Score: 2
>> Tie!

>> Would you like to play again?(Y/N)
Y
>> Playing Again!
>> Choose your player mode by typing A or B:
A)Player vs Player
B)Player vs Computer
...and so on 

```

