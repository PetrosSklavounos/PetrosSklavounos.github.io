
extern char three_board[3][3];
extern char five_board[5][5];
extern char letter;
extern char computer, playerone, playertwo;
extern int onescore, twoscore;

 char modechoice();
 char boardchoice();
 void init_boards(char size);
 void draw_three_board();
 void draw_five_board();
 void player1moveb3(int pos[]);
 void player1moveb5(int pos[]);
 void point_countb3p1(char three_board[][3], int row, int col);
 void point_countb5p1(char five_board[][5], int row, int col);
 void player2moveb3(int pos[]);
 void player2moveb5(int pos[]);
 void point_countb3p2(char three_board[][3], int row, int col);
 void point_countb5p2(char five_board[][5], int row, int col);
 void computerb3(int pos[]);
 void computerb5(int pos[]);
