#include <stdio.h>

#include "again.h"

int play_again() {
        char choice;
        printf("\n>> Would you like to play again?(Y/N)\n");
        do {
        choice = getchar();
        }
        while ((choice != 'Y') && (choice != 'N'));

        if(choice == 'Y') {
                printf(">> Playing Again!\n");
                return 1;
        }
        else if (choice == 'N') {
                printf(">> Thanks for playing!\n");
                return 0;
        }
}
