#include <stdio.h>

#include "setup.h"


char modechoice() {
        char mode;
         printf(">> Choose your player mode by typing A or B: \nA)Player vs Player\nB)Player vs Computer\n");
         do {
         mode = getchar();
         }
         while((mode != 'A') && (mode != 'B'));
                 if(mode == 'A') {
                         printf(">> You chose Player vs Player\n");
                         return 'A';
                 }
                 else if(mode == 'B') {
                         printf(">> You chose Player vs Computer\n");
                        return 'B';
                 }
         }

 char boardchoice() {
         char board;
         printf(">> Now choose the board size by typing A, B:\nA)3x3\nB)5x5\n");
         do {
         board = getchar();
         }
         while((board != 'A') && (board != 'B'));
                 if (board == 'A'){
                         printf(">> Board is 3X3\n");
                         return 'A';
                 }
                 else if (board == 'B'){
                         printf(">> Board is 5X5\n");
                         return 'B';
                 }
         }

 void init_boards(char size) {
         if (size == 'A'){
                 for(int row = 0; row <3; row++) {
                                for(int col=0; col<3; col++) {
                                three_board[row][col] = '-';
                              }
                 }
         }
         else if (size == 'B'){
                 for (int row= 0; row <5; row++) {
                         for(int col=0; col <5; col++) {
                                 five_board[row][col] = '-';
                                 }
                 }
         }
 }

 void draw_three_board() {
        int row;
        int col;
         for(row =0; row<3; row++) {
             printf("%c %c %c\n", three_board[row][0], three_board[row][1], three_board[row][2]);
         }
 }

 void draw_five_board() {
         int row;
         int col;
         for(row = 0; row<5; row++) {
                 printf("%c %c %c %c %c\n", five_board[row][0], five_board[row][1], five_board[row][2], five_board[row][3], five_board[row][4]);
                 }
         }
 void player1moveb3(int pos[]) {
     int spot, row, col;
         printf("\n>> Player 1's Turn\n");
          do {
                  printf(">> Choose a valid spot by typing a number between 1 and 9:\n");
                 scanf("%d", &spot);
                 while((spot<1) && (spot >9)) {
                          printf(">> Choose a valid spot by typing a number between 1 and 9:\n");
                          scanf("%d", &spot);
                  }
                  row = (spot -1)/3;
                  col = (spot -1)%3;

          }
          while(three_board[row][col] != '-');

          do {
              printf(">> Capital S or O?\n");
              scanf("%c", &letter);
             }
              while((letter != 'O') && (letter != 'S'));
            pos[0] = row;
              pos[1] = col;
             three_board[row][col] = letter;
 }

 void player1moveb5(int pos[]) {
         int spot, row, col;
         printf("\n>> Player 1's Turn\n");
         do {
                 printf(">> Choose a valid spot by typing a number between 1 and 25:\n");
                 scanf("%d", &spot);
                 while((spot<1) && (spot >25)) {
                         printf(">> Choose a valid spot by typing a number between 1 and 25:\n");
                         scanf("%d", &spot);
                 }
                 row = (spot -1)/5;
                 col = (spot -1)%5;

         }
         while(five_board[row][col] != '-');

         do {
                 printf(">> Capital S or O?\n");
                scanf("%c", &letter);
                 }
         while((letter != 'O') && (letter != 'S'));
         pos[0] = row;
         pos[1] = col;
         five_board[row][col] = letter;
 }
 void point_countb3p1(char three_board[][3], int row, int col) {
         if(three_board[row][col] == 'O') {
                 if(three_board[row-1][col] == 'S' && three_board[row+1][col] == 'S') {
                 onescore++;
                 }
                 if(three_board[row-1][col+1] == 'S' && three_board[row+1][col-1] == 'S') {
                 onescore++;
                 }
                 if(three_board[row-1][col-1] == 'S' && three_board[row +1][col+1] == 'S') {
                 onescore++;
                 }
                 if(three_board[row][col-1] == 'S' && three_board[row][col+1] == 'S') {
                 onescore++;
                 }
         }
         if(three_board[row][col] == 'S') {
                 if(three_board[row-1][col] == 'O' && three_board[row-2][col] == 'S') {
                 onescore++;
                 }
                 if(three_board[row][col-1] == 'O' && three_board[row][col-2] == 'S') {
                 onescore++;
                 }
                 if(three_board[row+1][col] == 'O' && three_board[row+2][col] == 'S') {
                 onescore++;
                 }
                 if(three_board[row][col+1] == 'O' && three_board[row][col+2] == 'S') {
                 onescore++;
                 }
                 if(three_board[row+1][col+1] == 'O' && three_board[row+2][col+2] == 'S') {
                 onescore++;
                 }
                 if(three_board[row-1][col-1] == 'O' && three_board[row-2][col-2] == 'S') {
                 onescore++;
                }
                 if(three_board[row-1][col+1] == 'O' && three_board[row-2][col+2] == 'S') {
                 onescore++;
                 }
                 if(three_board[row+1][col-1] == 'O' && three_board[row+2][col-2] == 'S') {
                 onescore++;
                 }
        }
        printf(">> Player one's score: %d\n", onescore);
        printf(">> Player two's score: %d\n", twoscore);
 }

 void point_countb5p1(char five_board[][5], int row, int col) {
         if(five_board[row][col] == 'O') {
                 if(five_board[row-1][col] == 'S' && five_board[row+1][col] == 'S') {
                onescore++;
                 }
                 if(five_board[row-1][col+1] == 'S' && five_board[row+1][col-1] == 'S') {
                 onescore++;
                }
                 if(five_board[row-1][col-1] == 'S' && five_board[row +1][col+1] == 'S') {
                 onescore++;
                 }
                 if(five_board[row][col-1] == 'S' && five_board[row][col+1] == 'S') {
                 onescore++;
                 }
        }
         if(five_board[row][col] == 'S') {
                 if(five_board[row-1][col] == 'O' && five_board[row-2][col] == 'S') {
                 onescore++;
                 }
                 if(five_board[row][col-1] == 'O' && five_board[row][col-2] == 'S') {
                 onescore++;
                 }
                 if(five_board[row+1][col] == 'O' && five_board[row+2][col] == 'S') {
                 onescore++;
                 }
                 if(five_board[row][col+1] == 'O' && five_board[row][col+2] == 'S') {
                 onescore++;
                 }
                 if(five_board[row+1][col+1] == 'O' && five_board[row+2][col+2] == 'S') {
                 onescore++;
                 }
                 if(five_board[row-1][col-1] == 'O' && five_board[row-2][col-2] == 'S') {
                 onescore++;
                 }
                if(five_board[row-1][col+1] == 'O' && five_board[row-2][col+2] == 'S') {
                 onescore++;
                 }
                 if(five_board[row+1][col-1] == 'O' && five_board[row+2][col-2] == 'S') {
                 onescore++;
                 }
         }
         printf(">> Player one Score: %d\n", onescore);
         printf(">> Player two Score: %d\n", twoscore);
         }

 void player2moveb3(int pos[]) {
         int spot, row, col;
         printf("\n>> Player 2's Turn\n");
         do {
                 printf(">> Choose a valid spot by typing a number between 1 and 9:\n");
                scanf("%d", &spot);
                 row = (spot-1)/3;
                 col = (spot-1)%3;
                 }
          while(three_board[row][col] != '-');

         do {
                printf(">> Capital S or O?\n");
                  scanf("%c", &letter);
                 }
        while((letter != 'O') && (letter != 'S'));
         pos[0] = row;
         pos[1] = col;
         three_board[row][col] = letter;
  }

 void player2moveb5(int pos[]) {
         int spot, row, col;
         printf("\n>> Player 2's Turn\n");
         do {
                 printf(">> Choose a spot by typing a number between 1 and 25:\n");
                 scanf("%d", &spot);
                row = (spot-1)/5;
                 col = (spot-1)%5;
                 }
         while(five_board[row][col] != '-');

         do {
                 printf(">> Caital S or O?\n");
                 scanf("%c", &letter);
                 }
         while((letter != 'O') && (letter != 'S'));
         pos[0] = row;
         pos[1] = col;
         five_board[row][col] = letter;
 }
void point_countb3p2(char three_board[][3], int row, int col) {
         if(three_board[row][col] == 'O') {
                 if(three_board[row-1][col] == 'S' && three_board[row+1][col] == 'S') {
                 twoscore++;
                 }
                 if(three_board[row-1][col+1] == 'S' && three_board[row+1][col-1] == 'S') {
                 twoscore++;
                 }
                 if(three_board[row-1][col-1] == 'S' && three_board[row +1][col+1] == 'S') {
                 twoscore++;
                 }
                 if(three_board[row][col-1] == 'S' && three_board[row][col+1] == 'S') {
                 twoscore++;
                 }
         }
         if(three_board[row][col] == 'S') {
                 if(three_board[row-1][col] == 'O' && three_board[row-2][col] == 'S') {
                 twoscore++;
                 }
                 if(three_board[row][col-1] == 'O' && three_board[row][col-2] == 'S') {
                 twoscore++;
                }
                 if(three_board[row+1][col] == 'O' && three_board[row+2][col] == 'S') {
                 twoscore++;
                 }
                 if(three_board[row][col+1] == 'O' && three_board[row][col+2] == 'S') {
                 twoscore++;
                 }
                 if(three_board[row+1][col+1] == 'O' && three_board[row+2][col+2] == 'S') {
                 twoscore++;
                }
                 if(three_board[row-1][col-1] == 'O' && three_board[row-2][col-2] == 'S') {
                 twoscore++;
                 }
                 if(three_board[row-1][col+1] == 'O' && three_board[row-2][col+2] == 'S') {
                 twoscore++;
                }
                 if(three_board[row+1][col-1] == 'O' && three_board[row+2][col-2] == 'S') {
                 twoscore++;
                 }

        }
         printf(">> Player one score: %d\n", onescore);
         printf(">> Player two score: %d\n", twoscore);
}
void point_countb5p2(char five_board[][5], int row, int col) {
         if(five_board[row][col] == 'O') {
                 if(five_board[row-1][col] == 'S' && five_board[row+1][col] == 'S') {
                twoscore++;
                 }
                 if(five_board[row-1][col+1] == 'S' && five_board[row+1][col-1] == 'S') {
                 twoscore++;
                 }
                 if(five_board[row-1][col-1] == 'S' && five_board[row +1][col+1] == 'S') {
                 twoscore++;
                 }
                 if(five_board[row][col-1] == 'S' && five_board[row][col+1] == 'S') {
                twoscore++;
                 }
         }
         if(five_board[row][col] == 'S') {
                 if(five_board[row-1][col] == 'O' && five_board[row-2][col] == 'S') {
                 twoscore++;
                 }
                 if(five_board[row][col-1] == 'O' && five_board[row][col-2] == 'S') {
                 twoscore++;
                 }
                 if(five_board[row+1][col] == 'O' && five_board[row+2][col] == 'S') {
                 twoscore++;
                 }
                 if(five_board[row][col+1] == 'O' && five_board[row][col+2] == 'S') {
                 twoscore++;
                 }
                 if(five_board[row+1][col+1] == 'O' && five_board[row+2][col+2] == 'S') {
                 twoscore++;
                 }
                if(five_board[row-1][col-1] == 'O' && five_board[row-2][col-2] == 'S') {
                 twoscore++;
                 }
                 if(five_board[row-1][col+1] == 'O' && five_board[row-2][col+2] == 'S') {
                 twoscore++;
                 }
                 if(five_board[row+1][col-1] == 'O' && five_board[row+2][col-2] == 'S') {
                 twoscore++;
                 }
         }
         printf(">> Player one Score: %d\n", onescore);
         printf(">> Player two Score: %d\n", twoscore);
         }

                 
 void computerb3(int pos[]) {
          printf(">> Computer moves:\n");
          int row = 0;
          int col = 0;
          int spot = 1;
          for( ; (three_board[row][col] == 'O') || (three_board[row][col] == 'S') ; spot++) {
                 row = (spot-1)/3;
                  col = (spot-1)%3;
          }
          pos[0] = row;
          pos[1] = col;
         three_board[row][col] = 'O';
 }

 void computerb5(int pos[]) {
        printf(">> Computer moves:\n");
        int row = 0;
         int col = 0;
         int spot = 1;
         for( ; (five_board[row][col] == 'O') || (five_board[row][col] == 'S') ; spot++) {
                 row = (spot-1)/5;
                 col = (spot-1)%5;
         }
         pos[0] = row;
         pos[1] = col;
         five_board[row][col] = 'O';
 }
