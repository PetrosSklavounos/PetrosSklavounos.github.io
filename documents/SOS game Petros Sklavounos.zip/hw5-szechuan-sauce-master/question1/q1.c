#include <stdio.h>
#include "setup.h"
#include "again.h"

char three_board[3][3];
char five_board[5][5];
char letter;
char computer, playerone, playertwo;
int onescore, twoscore;
 
 int main(void) {
         int playagain = 1;
         while (playagain != 0) {

         char mode = modechoice();
         char size = boardchoice();
         int col = 0;
         int row = 0;
         init_boards(size);
         onescore = 0;
         twoscore = 0;
         int pos[2];
                 if(mode == 'A' && size == 'B') {
                         draw_five_board();
                        printf(">> Player 1 Score: %d\n", onescore);
                        printf(">> Player 2 Score: %d\n", twoscore);
                         for(int i =0; i<25; i++) {
                                 if(i % 2 == 0) {
                                         player1moveb5(pos);
                                         draw_five_board();
                                         point_countb5p1(five_board, pos[0], pos[1]);
                                         }

                                 else if(i % 2 == 1) {
                                         player2moveb5(pos);
                                         draw_five_board();
                                         point_countb5p2(five_board, pos[0], pos[1]);
                                         }
                                 }
                         if(onescore  > twoscore) {
                                printf(">> Player One Wins!\n");
                                 }
                         if(onescore < twoscore) {
                               printf(">> Player Two Wins!\n");
                              }
                         if(onescore == twoscore) {
                                printf(">> Tie!\n");
                                 }
                 }
                 else if(mode == 'A' && size == 'A') {
                     draw_three_board();
                      printf(">> Player 1 Score: %d\n", onescore);
                      printf(">> Player 2 Score: %d\n", twoscore);
                      for(int i =0; i<9; i++) {
                          if(i % 2 == 0) {
                              player1moveb3(pos);
                              draw_three_board();
                              point_countb3p1(three_board, pos[0], pos[1]);
                                          }

                                 else if(i % 2 == 1) {
                                          player2moveb3(pos);
                                          draw_three_board();
                                         point_countb3p2(three_board, pos[0], pos[1]);
                                         }
                                 }
                          if(onescore  > twoscore) {
                                 printf(">> Player One Wins!\n");
                                  }
                          if(onescore < twoscore) {
                                 printf(">> Player Two Wins!\n");
                                  }
                          if(onescore == twoscore) {
                                 printf(">> Tie!\n");
                                  }

                         }

                 if(mode == 'B' && size == 'A') {
                         draw_three_board();
                         printf(">> You are Player 1\n");
                        printf(">> Player 1 Score: %d\n", onescore);
                         printf(">> Computer Score: %d\n", twoscore);
                         for(int i =0; i<9; i++) {
                                 if(i % 2 == 0) {
                                          player1moveb3(pos);
                                          draw_three_board();
                                          point_countb3p1(three_board, pos[0], pos[1]);
                                          }
                                 else if(i % 2 == 1) {
                                          computerb3(pos);
                                          draw_three_board();
                                          point_countb3p2(three_board, pos[0], pos[1]);
                                         }
                                 }
                           if(onescore  > twoscore) {
                                 printf(">> Player One Wins!\n");
                         }
                         if(onescore < twoscore) {
                                 printf(">> Player Two Wins!\n");
                                  }
                         if(onescore == twoscore) {
                                printf(">> Tie!\n");
                        }
                 }

                 if(mode == 'B' && size == 'B') {
                        draw_five_board();
                        printf(">> You are Player 1\n");
                        printf(">> Player 1 Score: %d\n", onescore);
                        printf(">> Computer Score: %d\n", twoscore);
                        for(int i =0; i<25; i++) {
                                if(i % 2 == 0) {
                                         player1moveb5(pos);
                                         draw_five_board();
                                         point_countb5p1(five_board, pos[0], pos[1]);
                                         }
                                else if(i % 2 == 1) {
                                         computerb5(pos);
                                         draw_five_board();
                                         point_countb5p2(five_board, pos[0], pos[1]);
                                         }
                                 }
                       if(onescore  > twoscore) {
                                printf(">> Player One Wins!\n");
                        }
                        if(onescore < twoscore) {
                                printf(">> Player Two Wins!\n");
                                 }
                        if(onescore == twoscore) {
                                printf(">> Tie!\n");
                        }
                 }

        playagain = play_again();
        }
        }

